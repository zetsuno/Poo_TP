#ifndef UTILS_H
#define UTILS_H
#include "nave.h"
#include "sala.h"
#include "sala_escudo.h"
#include "sala_maquinas.h"
#include "sala_maquinas_prop1.h"
#include "sala_maquinas_prop2.h"
#include "Sala_ponte.h"
#include "sala_vida.h"
#include "tripulantes.h"
#include "entidades.h"
#include "defines.h"
#include "sala_beliche.h"
#endif