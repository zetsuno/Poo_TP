#include "sala.h"


class sala_beliche : public sala {


public:
	sala_beliche();
	virtual ~sala_beliche();

};