#ifndef SALA_MAQUINAS_H
#define SALA_MAQUINAS_H
#include "sala.h"
class sala_maquinas: public sala {

	

public:
	
	bool Chk_Props() const;
	sala_maquinas();
	virtual ~sala_maquinas();
	
};




#endif